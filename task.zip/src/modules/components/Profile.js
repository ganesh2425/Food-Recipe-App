import React from 'react'

function Profile() {
  return (
<>
<h3>Profile</h3>
</>
  )
}

export default Profile