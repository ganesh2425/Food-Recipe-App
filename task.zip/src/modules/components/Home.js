import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";

function Home(props) {
  const [data, setData] = useState([]);
  const [ring, setRing] = useState([]);
  const [shirt, setShirt] = useState([]);
  const [pant, setPant] = useState([]);
  const [mobile, setMobile] = useState([]);
  // const img5 = "https://fakestoreapi.com/img/81Zt42ioCgL._AC_SX679_.jpg"

  let pushData = (ring)=>{
    props.pullData(ring)
  }

  useEffect(() => {
    axios
      .get("https://fakestoreapi.com/products/categories")
      .then((res) => {
        console.log(res);
        setData(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  useEffect(() => {
    axios
      .get("https://fakestoreapi.com/products/category/jewelery")
      .then((res) => {
        console.log(res);
        setRing(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  useEffect(() => {
    axios
      .get("https://fakestoreapi.com/products/category/electronics")
      .then((res) => {
        console.log(res);
        setMobile(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  useEffect(() => {
    axios
      .get("https://fakestoreapi.com/products/category/men's clothing")
      .then((res) => {
        console.log(res);
        setShirt(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  useEffect(() => {
    axios
      .get("https://fakestoreapi.com/products/category/women's clothing")
      .then((res) => {
        console.log(res);
        setPant(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  return (
    <>
      <section className="bg-warning p-2">
        <div className="container">
          <div className="row">
            <div className="col">
              <h3>Product Details</h3>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div className="container mt-4">
          <div className="row">
            <div className="col-md-3">
              <div className="card">
                <button>Electronics</button>
                
                    {mobile.map((item)=>(
                      <ul key={item.id}>
                        <li>{item.id}</li>
                          <img src={item.image} alt="image" width="100px" height="100px"/><br/>
                        
                        {item.category}<br/>
                        {item.price}
                      </ul>
                    ))}
                 
              </div>
            </div>
            <div className="col-md-3">
              <div className="card">
                <button>Jewellery</button>
                {ring.map((item)=>{
                  return(
                      <ul key={item.id} onClick={pushData.bind(this, ring)}>
                        
                        <li>{item.id}</li>
                       
                          <img src={item.image} alt="image" width="100px" height="100px"/><br/>
                        {item.category}<br/>
                        {item.price}
                      </ul>
                  )
})}
              </div>
            </div>
            <div className="col-md-3">
              <div className="card">
                <button>Men's clothing</button>
                {shirt.map((item)=>(
                      <ul key={item.id}>
                        <li>{item.id}</li>
                        
                          <img src={item.image} alt="image" width="100px" height="100px"/><br/>
                      
                        {item.category} <br/>
                        {item.price}
                      </ul>
                    ))}
              </div>
            </div>
            <div className="col-md-3">
              <div className="card">
                <button>Women's clothing</button>
                {pant.map((item)=>(
                      <ul key={item.id}>
                        <li>{item.id}</li>
                          <img src={item.image} alt="image" width="100px" height="100px"/><br/>
                        
                        {item.category}<br/>
                        {item.price}
                      </ul>
                    ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <ul>
        {data.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>

      
    </>
  );
}

export default Home;
