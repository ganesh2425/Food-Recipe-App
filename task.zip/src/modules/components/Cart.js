import React, { useEffect, useState } from 'react'
import axios from "axios";


function Cart() {
  const img1 = "https://fakestoreapi.com/img/51Y5NI-I5jL._AC_UX679_.jpg";

  const [pant, setPant] = useState([]);
  useEffect(() => {
    axios
      .get("https://fakestoreapi.com/products/category/women's clothing")
      .then((res) => {
        console.log(res);
        setPant(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  return (
    <>
    <h4>Cart Items</h4>
    {/* <img src={img1} alt="example" heigh="150px" width="150px"/> */}
    {pant.map((item)=>(
                      <ul key={item.id}>
                        <li>{item.id}</li>
                          <img src={item.image} alt="image" width="100px" height="100px"/><br/>
                        
                        <h5>Category:</h5>{item.category}<br/>
                        <h5>Price:</h5>{item.price}<br/>
                        <h5>Title:</h5>{item.title}<br/>
                        <h5>Rating:</h5>{item.rating.rate}<br/>
                        
                      </ul>
                    ))}
    </>
  )
}

export default Cart