import axios from 'axios';
import React, { useEffect, useState } from 'react'

function Products() {
  const [data, setData] = useState([]);

  useEffect(()=>{
    axios.get("https://fakestoreapi.com/products/6")
    .then((res)=>{
      console.log(res.data)
      setData(res.data)
    })
    .catch((err)=>{
      console.log(err)
    })
  },[]);
  return (
    <>
    <h3>Product Details</h3>
    
      {/* {data&&data.map((item)=>(
        <ul key={item.id}>
          <li>{item.id}</li>
        </ul>
      ))} */}
    
    </>
  )
}

export default Products