import './App.css';
import { BrowserRouter, Route, Routes  } from 'react-router-dom';
import Navbar from './modules/navbar/Navbar';
import Home from './modules/components/Home';
import Cart from './modules/components/Cart';
import Products from './modules/components/Products';
import Profile from './modules/components/Profile';

function App() {
  return (
    <>
    <BrowserRouter>
    <Navbar/>
    <Routes>
      <Route path="/home" element={<Home/>}/>
      <Route path="/cart" element={<Cart/>}/>
      <Route path="/products" element={<Products/>}/>
      <Route path="/profile" element={<Profile/>}/>
    </Routes>
    </BrowserRouter>
    </>
  );
}

export default App;
